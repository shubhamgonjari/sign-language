# sign language detection > 2024-06-22 9:59am
https://universe.roboflow.com/shubham-gonjari/sign-language-detection-bj1vl

Provided by a Roboflow user
License: CC BY 4.0

